import { Component } from '@angular/core';
import { Product } from './product';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-pagination-app';
  products: Product[] = [
    {id: 1, name: 'iphone', model: '6', price: 9999},
    {id: 2, name: 'iphone', model: '6s', price: 10999},
    {id: 3, name: 'iphone', model: '7', price: 11999},
    {id: 4, name: 'iphone', model: '7s', price: 12999},
    {id: 5, name: 'iphone', model: '8', price: 13999},
    {id: 6, name: 'samsung', model: 'note 6', price: 5999},
    {id: 7, name: 'samsung', model: 's4 mini', price: 3999},
    {id: 8, name: 'samsung', model: 's3 mini', price: 2999},
    {id: 9, name: 'samsung', model: 'galaxy edge s9', price: 51999},
    {id: 10, name: 'samsung', model: 'galaxy on 7', price: 6999},
    {id: 11, name: 'samsung', model: 'next 8', price: 4999},
    {id: 12, name: 'samsung', model: 'galaxy duos', price: 2999},

  ]
}
