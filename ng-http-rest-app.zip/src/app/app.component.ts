import { Component } from '@angular/core';
import { Http, Headers } from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  products;

  message;

  getRequest() {
    this.http.get("http://localhost:3000/products")
    .subscribe((data)=>this.products=data.json())
  }

  addProduct() {
    var product = JSON.stringify({name: 'samsung', model: 'note 8', price: 8999})
    var header = new Headers({'Content-Type': 'application/json'})
    this.http.post("http://localhost:3000/products", product, {headers: header})
    .subscribe(()=>this.message="product has been added successfully")
  }

  constructor(private http: Http){}
}
