var mongo = require('mongodb').MongoClient
var cors = require('cors');
var express = require('express');
var bp = require('body-parser')
var app = express();
app.use(cors());
app.use(bp.json());
app.use(bp.urlencoded({extended: true}))
app.listen(5000, ()=>console.log('server is listening'));

var url = "mongodb://localhost:27017/productstore"

mongo.connect(url, (err, db)=>{
    var d = db.db('productstore');
    d.createCollection('user_details', (err, msg)=>{
        console.log('collection create...')
    })
    var sql = {name: 'rajesh', pass: '123', role: 'admin'}
    d.collection('user_details').insertOne(sql, (err, res)=>{
        console.log('document inserted...')
    })
})

app.post('/loginuser', (req, res)=>{
    mongo.connect(url, (err, db)=>{
        var d = db.db('productstore');
        d.collection('user_details').findOne(req.body, (err, msg)=>{
            res.json(msg)
            console.log('user: ' + req.body.name)
        })
    })
})
