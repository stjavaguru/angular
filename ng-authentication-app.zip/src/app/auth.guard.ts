import { AuthorizationService } from './authorization.service';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalStorageService } from 'ngx-webstorage';
import {Router} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.localStorage.retrieve('user')) {
      return true;
    }
    this.route.navigate([''])
  }
  constructor(private authService: AuthorizationService, private localStorage: LocalStorageService, private route: Router){}


  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    var roles = next.data.roles;
    var isValid = this.authService.isAuthroized(roles);
    if (!isValid) {
      alert('your not allowed to access this page')
    }
    return isValid;
  }













}
