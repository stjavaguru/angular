import { LocalStorageService } from 'ngx-webstorage';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private route: Router, private localStorage: LocalStorageService) { }

  userName;
  ngOnInit() {
    this.userName = this.localStorage.retrieve('user').name;
  }

  logout() {
    this.localStorage.clear('user');
    this.route.navigate([''])

  }

}
