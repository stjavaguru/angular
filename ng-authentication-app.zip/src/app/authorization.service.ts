import { LocalStorageService } from 'ngx-webstorage';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {

  constructor(private http: Http, private localStorage: LocalStorageService) { 
    this.userSubject = new BehaviorSubject(null);
  }

  userSubject: BehaviorSubject<any>;

 get userName() {
   return this.userSubject.asObservable();
 }

 setUsername() {
   this.userSubject.next('ambani')
 }

  



  validateUser(username, password) {
    return this.http.post('http://localhost:5000/loginuser', {name: username, pass: password})
    .toPromise()
    .then(res=>{return res.json()})
  }

  isAuthroized(allowedRoles: string[]): boolean {
    if (allowedRoles == null || allowedRoles.length == 0) {
      return true;
    }
    return allowedRoles.includes(this.localStorage.retrieve('user').role)
  }
}
