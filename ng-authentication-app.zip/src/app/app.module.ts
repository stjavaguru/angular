import { AuthGuard } from './auth.guard';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {RouterModule, Routes} from '@angular/router'
import {HttpModule} from '@angular/http';
import { HomeComponent } from './home/home.component'
import {NgxWebstorageModule} from 'ngx-webstorage';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component'

const routes: Routes = [
  {
    path: '',
    canActivateChild: [AuthGuard],
    children: [
      {
        path: '', component: LoginComponent, data: {}
      },
      {
        path: 'home', component: HomeComponent, data: {roles: ['admin']}
      },
      {
        path: 'about', component: AboutComponent, data: {roles: ['user']}
      },
      {
        path: 'contact', component: ContactComponent, data: {roles: ['user']}
      }
    ]
  }
]


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpModule,
    NgxWebstorageModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }