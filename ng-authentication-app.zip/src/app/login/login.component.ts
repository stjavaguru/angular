import { AuthorizationService } from './../authorization.service';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private localStorage: LocalStorageService, private authService: AuthorizationService, private route: Router) { }

  username;
  pass;

  user;
  login() {
    this.increment.emit(++this.counter)
    this.authService.setUsername();
    this.authService.userSubject.subscribe(username=>this.user=username);
    this.authService.validateUser(this.username, this.pass)
    .then((res)=>{
      if (res) {
        this.localStorage.store('user', res);
        this.route.navigate(['home'])
      }
      else {
        alert('login failed')
      }

    })
  }
  ngOnInit() {
  }

  counter = 1;

  @Output() increment = new EventEmitter();



}
