import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value, x) {
    
    var da = [];

    for (var i = 0; i < value.length; i++) {
      if (value[i].indexOf(x) != -1) {
        da.push(value[i])
      }

    }
    return da;

  }

}
