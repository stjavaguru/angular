import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-directives-app';


  states = ['ts', 'ap'];
  tscities = ['hyd', 'warangal', 'secbad']
  apcities = ['guntur', 'vizag', 'vijayawada']



  myFunction() {
    return false;
  }




  peopleByCity = [
    {
      city: 'Hyderabad',
      people: [
        {name: 'raju', age: 44},
        {name: 'vijay', age: 78}
      ]
    },

    {
      city: 'Vijayawada',
      people: [
        {name: 'babu', age: 67},
        {name: 'jagan', age: 56}
      ]
    }
  ]

  isBordered = false;

  applyStyle() {
    this.isBordered = !this.isBordered
  }

  d = new Date()

  languages = ['java', 'pega', 'angular', 'react']

  products = [
    {id: 1, name: 'iphone', model: '6s', price: 21000},
    {id: 2, name: 'samsung', model: 'galaxy s9', price: 24000},
    {id: 3, name: 'mi', model: 'note 6', price: 19000},
  ]
}
