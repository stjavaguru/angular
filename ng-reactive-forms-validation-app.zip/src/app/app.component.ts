import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-reactive-forms-validation-app';
 
  
  
  myForm = new FormGroup({
    firstname: new FormControl('', [Validators.required]),
    middlename: new FormControl(),
    lastname: new FormControl('', [Validators.required]),
    passwords: new FormGroup({
      password: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[&@#%]).{8,}$/)]),
      confirmPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[&@#%]).{8,}$/)])
    }, {validators: this.passwordConfirming}),
    gender: new FormControl('', [Validators.required]),
    mail: new FormControl('', [Validators.required, Validators.email]),
    contact: new FormControl('', [Validators.required, Validators.pattern(/^(91|0)?[6-9][0-9]{9}$/)]),
    city: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required]),
    pinCode: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]{6}$/)]),
    langs: new FormControl('', [Validators.requiredTrue])
  })

  pass;
  cpass;
  passwordConfirming(c: AbstractControl): {invalid: boolean} {
    if (c.get('password').value != c.get('confirmPassword').value) {
      
      return {invalid: true}
    }
  }

  cities_ts = ['Hyderabad', 'Warangal', 'Kodad', 'Suryapet', 'Karimnagar', 'Adilabad', 'Medak', 'Medchal']
  cities_ap = ['Vijayawada', 'Vizag', 'Nellore', 'Guntur', 'Nandigama', 'Rajamandry', 'Vijayanagaram', 'Nandyala']

  error_messages = {
    'firstname': [
      {type: 'required', message: 'this field is required'},
    ],
    'lastname': [
      {type: 'required', message: 'this field is required'},
    ],
    'password': [
      {type: 'required', message: 'this field is required'},
      {type: 'pattern', message: 'invalid password'}
    ],
    'confirmPassword': [
      {type: 'required', message: 'this field is required'},
      {type: 'pattern', message: 'invalid confirm password'}
    ],
    'gender': [
      {type: 'required', message: 'this field is required'},
    ],
    'langs': [
      {type: 'required', message: 'this field is required'},
    ],
    'state': [
      {type: 'required', message: 'this field is required'},
    ],
    'city': [
      {type: 'required', message: 'this field is required'},
    ],
    'pinCode': [
      {type: 'required', message: 'this field is required'},
      {type: 'pattern', message: 'invalid pincode'}
    ],
    'mail': [
      {type: 'required', message: 'this field is required'},
      {type: 'email', message: 'invalid mail id'}
    ],
    'contact': [
      {type: 'pattern', message: 'invalid contact number'},
      {type: 'required', message: 'this field is required'},
    ]
  }

  
    
    
  

}
