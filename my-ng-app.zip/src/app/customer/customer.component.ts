import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer',
  template: `
    <p>
      customer works!
    </p>
  `,
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
