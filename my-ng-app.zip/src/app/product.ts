export interface Product {
    id: number
    name: string
    model: string
    price: number
}
