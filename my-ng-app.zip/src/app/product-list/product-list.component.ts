import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  products: Product[] = []
  constructor(service: ProductService) { 
    this.products = service.getAllProducts();
  }

  ngOnInit() {
  }

  product;

  selectedProduct(pro) {
    this.product = pro;
  }

}










