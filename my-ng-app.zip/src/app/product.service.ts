import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }

  getAllProducts(): Product[] {
    return [
      {id: 1, name: 'iphone', model: '6s', price: 13000},
    {id: 2, name: 'samsung', model: 'galaxy s9', price: 23000},
    {id: 3, name: 'redmi', model: 'note 5', price: 9000}
    ]
    
  }
}
