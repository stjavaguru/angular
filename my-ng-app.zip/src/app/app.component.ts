import { Component } from '@angular/core';
import { Product } from './product';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-ng-app';

  fruits = ['banana', 'apple', 'oragne', 'mango']

  

  // sayHello() {
  //   alert("good evening")
  // }

  sayHello = ()=> {
    alert("good evening")
  }

 langs = [];

 lang = '';

 addLang() {
   this.langs.push(this.lang);
 }

 remove(ind) {
   this.langs.splice(ind, 1);
 }
}
