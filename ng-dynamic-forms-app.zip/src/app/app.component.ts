import { Component } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-dynamic-forms-app';

  myForm = new FormGroup({
    fileUpload: new  FormArray([new FormControl()])
  })

  addField() {
    this.myForm.controls.fileUpload.push(new FormControl())
  }

  deleteField(ind) {
    this.myForm.controls['fileUpload'].removeAt(ind);
  }
}
