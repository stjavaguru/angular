var mail = require('emailjs/email');

var server = mail.server.connect({
    host: 'smtp-mail.outlook.com', //'smtp.gmail.com',
    user: 'nagaraju.setti@capgemini.com',
    password: 'your password',
    tls: {ciphers: "SSLv3"}
})

var message = {
    text: 'hello this is for testing a mail',
    from: 'nagaraju.setti@capgemini.com',
    to: 'nagaraju.setti@capgemini.com',
    subject: 'test',
    attachment: [
        {path: 'D:/E_And_Y/ng-node-mongo-app/src/node_exp.js', type: 'application/x-javascript'},
        {data: '<html><body><a href="reset.html">reset password</a></body></html>', alternative: true}
    ]
}

server.send(message, (err, res)=>{
    if (err) throw err;
    console.log('sent...')
})

