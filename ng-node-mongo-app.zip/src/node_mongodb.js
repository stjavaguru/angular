var mongo = require('mongodb').MongoClient

var url = "mongodb://localhost:27017/customers"

mongo.connect(url, (err, db)=>{
    if (err) throw err;
    console.log('database connected')
    var dao = db.db('customers');
    // dao.createCollection('customers_details', 
    // (err, msg)=> {
    //     if (err) throw err;
    //     console.log('collection created')
    // })

    // var customer = {name: 'lokesh',  age: 109, city: 'hyderabad',age: 103}

    // dao.collection('customers_details').insertOne(customer, (err, msg)=>{
    //     if (err) throw err;
    //     console.log('inserted...')
    // });
    // dao.collection('customers_details').find().toArray((err, result)=>{
    //     if (err) throw err;
    //     console.log(result)
    // })

//    var customers = [
//        {name: 'rakul', age: 29, city: 'mumbai'},
//        {name: 'vijay', age: 45, city: 'hyderabad'},
//        {name: 'tej', age: 34, city: 'hyderabad'}
//    ]

//    dao.collection('customers_details').insertMany(customers, (err, msg)=>{
//        if (err) throw err;
//        console.log(msg)
//    })

var query = {age: {$lt: 40}};

dao.collection('customers_details').find(query).toArray((err, msg)=>{
    if (err) throw err;
    console.log(msg)
})

var customer = {
    name: 'vijay'
}

dao.collection('customers_details').deleteOne(customer, (err, msg)=>{
    if (err) throw err;
    console.log('deleted...')
})

var q1 = {name: 'tej'}
var q2 = {$set: {age: 39}}
dao.collection('customers_details').updateOne(q1, q2, (err, msg)=>{
    if (err) throw err;
    console.log('updated...')
})

dao.collection('customers_details').find().toArray((err, msg)=>{
    console.log(msg)
})

})