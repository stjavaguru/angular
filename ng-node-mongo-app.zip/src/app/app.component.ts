import { Component } from '@angular/core';
import { Http, Headers } from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-node-mongo-app';
  constructor(private http: Http){}

  message;
  addproduct() {
    var product = JSON.stringify({name: 'iphone', model: '6s', price: 28900})
    var header = new Headers({'Content-Type': 'application/json'})
    this.http.post('http://localhost:8020/add', product, {headers: header})
    .subscribe(()=>{this.message="added successfully";
  this.showAll()})
  }

  products;
  showAll() {
    this.http.get('http://localhost:8020/getall')
    .subscribe((data)=>this.products=data.json())
  }

  update(pid) {
    var product = JSON.stringify({name: 'nokia', model: '6.1', price: 7999})
    var header = new Headers({'Content-Type': 'application/json'})
    this.http.put('http://localhost:8020/update/'+pid, product, {headers: header})
    .subscribe(()=>{
      this.message="updated...";
      this.showAll();
    })
  }
}
