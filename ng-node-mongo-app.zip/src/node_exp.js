var express = require('express')

var app = express()

app.listen(4000, ()=>{
    console.log('server started...')
    console.log('http://localhost:4000')
})

app.get('/users', (req, res)=> {
    res.send('get request has been processed...')
})

app.post('/add', (req, res)=> {
    console.log(req.body)
    res.send('user is added')
})

app.put('/update', (req, res)=> {
    res.send('put request')
})

app.delete('/delete', (req, re)=> {
    res.send('delete request')
})