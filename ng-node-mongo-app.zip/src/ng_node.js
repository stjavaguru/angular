var mongo = require('mongodb').MongoClient
var objectId = require('mongodb').ObjectID
var express = require('express');
var app = express();
var cors = require('cors')
app.use(cors())
var bp = require('body-parser')
app.use(bp.urlencoded({extended: true}))
app.use(bp.json())
app.listen(8020, ()=>console.log('listening server on port: 8020'))
var url = "mongodb://localhost:27017/productsdao"
mongo.connect(url, (err, db)=> {
    if (err) throw err;
    var d = db.db('productsdao');
    d.createCollection('products', (err, msg)=> {
        if (err) throw err;
        console.log('collection created')
    })
})

app.post('/add', (req, res)=> {
    mongo.connect(url, (err, db)=>{
        var d = db.db('productsdao')
        d.collection('products').insertOne(req.body, (err, msg)=>{
            if (err) throw err;
            res.json(msg);
            console.log('document inserted...')
        })
    })
})

app.get('/getall', (req, res)=> {
    mongo.connect(url, (err, db)=> {
        var d = db.db('productsdao')
        d.collection('products').find().toArray((err, msg)=> {
            if (err) throw err;
            res.json(msg)
        })
    })
})

app.put('/update/:id', (req, res)=>{
    mongo.connect(url, (err, db)=>{
        var d = db.db('productsdao')
        var q1 = {_id: objectId(req.params.id)}
        var q2 = {$set: {name: req.body.name, model: req.body.model, price: req.body.price}}
        d.collection('products').updateOne(q1,q2, (err, msg)=>{
            if (err) throw err;
            res.json(msg)
            console.log(msg)
        })
    })
})