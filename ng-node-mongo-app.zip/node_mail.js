var mail = require('emailjs/email');

var server = mail.server.connect({
    host: 'smtp.gmail.com',
    user: 'stjavaguru@gmail.com',
    password: 'Radhi@1988',
    ssl: true
})

var message = {
    text: 'hello this is for testing a mail',
    from: 'stjavaguru@gmail.com',
    to: 'setti.nagaraju@gmail.com',
    subject: 'test'
}

server.send(message, (err, res)=>{
    if (err) throw err;
    console.log('sent...')
})

