import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  myForm = new FormGroup({
    firstname: new FormControl('', [
      Validators.required,
      Validators.maxLength(10)
    ]),
    lastname: new FormControl(),
    address: new FormGroup({
      city: new FormControl('', [Validators.required]),
      state: new FormControl(),
      pincode: new FormControl()
    })
    
  })

  error_messages = {
    'firstname': [
      {type: 'required', message: 'field should not be empty'},
      {type: 'maxlength', message: 'max no of chars are 10 in length'}
    ],
    'city': [
      {type: 'required', message: 'filed is required'}
    ]
  }


  myAddress = new FormGroup({
    address: new FormArray([new FormControl()])
  })

  addAddr() {
    this.myAddress.controls.address.push(new FormControl())
  }
  removeAddr(ind) {
    this.myAddress.controls['address'].removeAt(ind);
  }

  myFile = new FormGroup({
    fileUpload: new FormArray([new FormControl()])
  })

  addFile() {
    this.myFile.controls.fileUpload.push(new FormControl())
  }

  removeFile(index) {
    this.myFile.controls['fileUpload'].removeAt(index);
  }
}
