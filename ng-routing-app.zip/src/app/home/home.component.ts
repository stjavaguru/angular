import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  products = [
    {id: 1, name: 'iphone', model: '6s', price: 9800},
    {id: 2, name: 'iphone', model: '6s', price: 9800},
    {id: 3, name: 'iphone', model: '6s', price: 9800},
    {id: 4, name: 'iphone', model: '6s', price: 9800},
    {id: 5, name: 'iphone', model: '6s', price: 9800},
    {id: 6, name: 'iphone', model: '6s', price: 9800},
    {id: 7, name: 'iphone', model: '6s', price: 9800},
    {id: 8, name: 'iphone', model: '6s', price: 9800},
    {id: 9, name: 'iphone', model: '6s', price: 9800},
    {id: 10, name: 'iphone', model: '6s', price: 9800},
    {id: 11, name: 'iphone', model: '6s', price: 9800},
    {id: 12, name: 'iphone', model: '6s', price: 9800},
  ]
  constructor() { }

  ngOnInit() {
  }

  p = 1;
}
